#
# hostname.sh	Set hostname.
#
# Version:	@(#)hostname.sh  1.00  22-Jun-1998  miquels@cistron.nl
#

hostname --file /etc/hostname

